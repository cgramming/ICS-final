/*
* Swapnil Kabir and Syed Bazif Shah
* Date: December 11, 2024
* Description: This class starts a game of Top-Down Duel by creating an instance of the GameFrame constructor.
*/

public class Main {
   public static void main(String[] args) {
       new GameFrame(); // Create new instance of GameFrame
   }
}
